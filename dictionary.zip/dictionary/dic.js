document.addEventListener('DOMContentLoaded', function () {
    const wordInput = document.getElementById('wordInput');
    const searchBtn = document.getElementById('searchBtn');
    const loading = document.getElementById('loading');
    const errorMessage = document.getElementById('errorMessage');
    const wordCard = document.getElementById('wordCard');
    const wordTitle = document.getElementById('wordTitle');
    const phonetic = document.getElementById('phonetic');
    const pronounceBtn = document.getElementById('pronounceBtn');
    const wordContent = document.getElementById('wordContent');

    // Search when button is clicked
    searchBtn.addEventListener('click', searchWord);

    // Search when Enter key is pressed
    wordInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            searchWord();
        }
    });

    function searchWord() {
        const word = wordInput.value.trim();

        if (!word) {
            return;
        }

        // Show loading, hide other elements
        loading.style.display = 'block';
        errorMessage.style.display = 'none';
        wordCard.style.display = 'none';

        fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Word not found');
                }
                return response.json();
            })
            .then(data => {
                displayWordData(data[0]);
            })
            .catch(error => {
                console.error('Error:', error);
                loading.style.display = 'none';
                errorMessage.style.display = 'block';
            });
    }

    function displayWordData(wordData) {
        loading.style.display = 'none';
        wordCard.style.display = 'block';

        // Set word title
        wordTitle.textContent = wordData.word;

        // Set phonetic text (use the first phonetic available)
        const firstPhonetic = wordData.phonetics.find(p => p.text)?.text || 'No phonetic available';
        phonetic.textContent = firstPhonetic;

        // Find audio URL (use the first audio available)
        const audioUrl = wordData.phonetics.find(p => p.audio)?.audio;

        // Set up pronunciation button
        if (audioUrl) {
            pronounceBtn.style.display = 'flex';
            pronounceBtn.onclick = function () {
                const audio = new Audio(audioUrl);
                audio.currentTime = 0;
                audio.play();
            };
        } else {
            pronounceBtn.style.display = 'none';
        }

        // Clear previous content
        wordContent.innerHTML = '';

        // Process each meaning
        wordData.meanings.forEach(meaning => {
            const meaningDiv = document.createElement('div');

            // Part of speech
            const partOfSpeech = document.createElement('p');
            partOfSpeech.className = 'part-of-speech';
            partOfSpeech.textContent = meaning.partOfSpeech;
            meaningDiv.appendChild(partOfSpeech);

            // Definitions and examples
            meaning.definitions.forEach((def, index) => {
                // Limit to 5 definitions per part of speech to keep it manageable
                if (index < 5) {
                    const definition = document.createElement('div');
                    definition.className = 'definition';

                    // Definition text
                    const defText = document.createElement('p');
                    defText.innerHTML = `<strong>${index + 1}.</strong> ${def.definition}`;
                    definition.appendChild(defText);

                    // Example if available
                    if (def.example) {
                        const example = document.createElement('div');
                        example.className = 'example';
                        example.textContent = `Example: ${def.example}`;
                        definition.appendChild(example);
                    }

                    meaningDiv.appendChild(definition);
                }
            });

            wordContent.appendChild(meaningDiv);
        });

        // Scroll to the word card
        wordCard.scrollIntoView({ behavior: 'smooth' });
    }
});

